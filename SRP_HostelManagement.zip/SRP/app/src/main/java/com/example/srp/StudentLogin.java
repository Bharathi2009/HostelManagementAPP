package com.example.srp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StudentLogin extends AppCompatActivity {

    EditText usernameEdit, passwordEdit;
    String usernameString, passwordString;
    DBAdapterStudent dbAdapterStudent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studentlogin);
        Initialization();
    }

    public void Initialization() {
        dbAdapterStudent = new DBAdapterStudent(StudentLogin.this);
        usernameEdit = findViewById(R.id.username);
        passwordEdit = findViewById(R.id.password);
    }

    public void loginImplementation(View view) {
        usernameString = usernameEdit.getText().toString();
        passwordString = passwordEdit.getText().toString();

        if (usernameString.isEmpty() || passwordString.isEmpty()) {
            Toast.makeText(StudentLogin.this, "Please verify all the fields", Toast.LENGTH_LONG).show();
        } else {
            try {
                dbAdapterStudent.open();
                String getPassword = dbAdapterStudent.getpassword(usernameString);
                if (getPassword.equalsIgnoreCase(passwordString)) {
                    Intent in = new Intent(StudentLogin.this, StudentHome.class);
                    startActivity(in);
                    usernameEdit.setText("");
                    passwordEdit.setText("");
                } else {
                    Toast.makeText(StudentLogin.this, "Invalid User name or Password", Toast.LENGTH_LONG).show();
                }
                dbAdapterStudent.close();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(StudentLogin.this, "Invalid User name or Password", Toast.LENGTH_LONG).show();
            }


        }
    }

    public void signupImplementation(View view) {
        Intent in = new Intent(StudentLogin.this, Studentsignup.class);
        startActivity(in);
    }

}