package com.example.srp;

import android.database.SQLException;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class UploadMessFeedback extends AppCompatActivity {


    Button submitButton;
    RadioGroup qOneGroup, qTwoGroup, qThreeGroup, qFourGroup, qFiveGroup;
    RadioButton qOneButton, qTwoButton, qThreeButton, qFourButton, qFiveButton;
    DBAdapterMessComment dbc;

    String getusername;
    ArrayList<String> ratingArrayList = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.uploadmessfeedback);

        dbc = new DBAdapterMessComment(UploadMessFeedback.this);

        getusername = getIntent().getStringExtra("fusername");



        qOneGroup = findViewById(R.id.rgOne);
        qTwoGroup = findViewById(R.id.rgTwo);
        qThreeGroup = findViewById(R.id.rgThree);
        qFourGroup = findViewById(R.id.rgFour);
        qFiveGroup = findViewById(R.id.rgFive);

        submitButton = findViewById(R.id.submit);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int qOneId = qOneGroup.getCheckedRadioButtonId();
                int qTwoId = qTwoGroup.getCheckedRadioButtonId();
                int qThreeId = qThreeGroup.getCheckedRadioButtonId();
                int qFourId = qFourGroup.getCheckedRadioButtonId();
                int qFiveId = qFiveGroup.getCheckedRadioButtonId();


                // find the radiobutton by returned id
                qOneButton = findViewById(qOneId);
                qTwoButton = findViewById(qTwoId);
                qThreeButton = findViewById(qThreeId);
                qFourButton = findViewById(qFourId);
                qFiveButton = findViewById(qFiveId);


                ratingArrayList.add("Vessels are Cleaned properly");
                ratingArrayList.add("Rating: " + qOneButton.getText().toString());
                ratingArrayList.add("FoodProvided on time");
                ratingArrayList.add("Rating: " + qTwoButton.getText().toString());
                ratingArrayList.add("Quality of food");
                ratingArrayList.add("Rating: " + qThreeButton.getText().toString());
                ratingArrayList.add("Drinking Water facilites");
                ratingArrayList.add("Rating: " + qFourButton.getText().toString());
                ratingArrayList.add("Hygenic of food");
                ratingArrayList.add("Rating: " + qFiveButton.getText().toString());


                if (ratingArrayList.size() > 5) {
                    dbc.open();
                    long id = dbc.insertmesscomment(getusername, "Submitted",""+ratingArrayList);
                    dbc.close();


                    if (id > 0) {
                        Toast.makeText(UploadMessFeedback.this, "Comment uploaded successfully", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(UploadMessFeedback.this, "Please verify all the details", Toast.LENGTH_LONG).show();
                }

            }

        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        ratingArrayList.clear();
    }
}
