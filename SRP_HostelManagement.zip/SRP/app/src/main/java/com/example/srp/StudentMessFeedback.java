package com.example.srp;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class StudentMessFeedback extends AppCompatActivity {

    ListView flist;

    DBAdapterMess dbf;
    Cursor c;

    ArrayList<String> idList = new ArrayList<>();
    ArrayList<String> nameList = new ArrayList<>();
    ArrayList<String> boysgirlsList = new ArrayList<>();
    ArrayList<String> mobileList = new ArrayList<>();
    ArrayList<String> mailList = new ArrayList<>();
    ArrayList<String> usernameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studentmessfeedback);

        dbf=new DBAdapterMess(StudentMessFeedback.this);

        flist = (ListView) findViewById(R.id.flistview);

        flist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in=new Intent(StudentMessFeedback.this,UploadMessFeedback.class);
                in.putExtra("fusername",usernameList.get(position).toString());
                startActivity(in);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        idList.clear();
        nameList.clear();
        boysgirlsList.clear();
        mobileList.clear();
        mailList.clear();
        usernameList.clear();

        dbf.open();
        c=dbf.getAllAccounts();

        if (c.getCount()>0)
        {
            c.moveToFirst();

            do {

                String id=c.getString(c.getColumnIndex("id"));
                String name=c.getString(c.getColumnIndex("name"));
                String boysgirls=c.getString(c.getColumnIndex("boysgirls"));
                String mobile=c.getString(c.getColumnIndex("mobile"));
                String mail=c.getString(c.getColumnIndex("mail"));
                String username=c.getString(c.getColumnIndex("username"));

                idList.add(id);
                nameList.add(name);
                boysgirlsList.add(boysgirls);
                mobileList.add(mobile);
                mailList.add(mail);
                usernameList.add(username);

            }while (c.moveToNext());

            ArrayAdapter<String> fAdapter=new ArrayAdapter<String>(StudentMessFeedback.this,android.R.layout.simple_list_item_1,nameList);
            flist.setAdapter(fAdapter);

        }
        else
        {
            Toast.makeText(StudentMessFeedback.this,"No Mess found",Toast.LENGTH_LONG).show();
        }

        dbf.close();
    }
}
