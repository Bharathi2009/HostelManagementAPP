package com.example.srp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.srp.AdminLogin;
import com.example.srp.R;
import com.example.srp.StudentLogin;

public class StudentHome extends AppCompatActivity {

    CardView shfeedback;
    CardView smfeedback;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_home);

        shfeedback=findViewById(R.id.studentfeedback);
        smfeedback=findViewById(R.id.messfeedback);

        shfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StudentHome.this, StudentHostelFeedback.class));

            }
        });

        smfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudentHome.this,StudentMessFeedback.class));
            }
        });

    }
}