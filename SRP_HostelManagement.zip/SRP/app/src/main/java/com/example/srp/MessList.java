package com.example.srp;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MessList extends AppCompatActivity {

    Button addmessButton;
    ListView flistView;

    DBAdapterMess dbf;
    Cursor c;

    ArrayList<String> idList=new ArrayList<>();
    ArrayList<String> nameList=new ArrayList<>();
    ArrayList<String> boysgirlsList=new ArrayList<>();
    ArrayList<String> mobileList=new ArrayList<>();
    ArrayList<String> mailList=new ArrayList<>();
    ArrayList<String> usernameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mess_list);

        dbf=new DBAdapterMess(MessList.this);

        addmessButton= (Button) findViewById(R.id.addmess);
        flistView= (ListView) findViewById(R.id.messlist);

        addmessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(MessList.this,AddMess.class);
                startActivity(in);

            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

        idList.clear();
        nameList.clear();
        boysgirlsList.clear();
        mobileList.clear();
        mailList.clear();
        usernameList.clear();

        dbf.open();
        c=dbf.getAllAccounts();

        if (c.getCount()>0)
        {
            c.moveToFirst();

            do {

                String id=c.getString(c.getColumnIndex("id"));
                String name=c.getString(c.getColumnIndex("name"));
                String boysgirls=c.getString(c.getColumnIndex("boysgirls"));
                String mobile=c.getString(c.getColumnIndex("mobile"));
                String mail=c.getString(c.getColumnIndex("mail"));
                String username=c.getString(c.getColumnIndex("username"));

                idList.add(id);
                nameList.add(name);
                boysgirlsList.add(boysgirls);
                mobileList.add(mobile);
                mailList.add(mail);
                usernameList.add(username);

            }while (c.moveToNext());

            ArrayAdapter<String> fAdapter=new ArrayAdapter<String>(MessList.this,android.R.layout.simple_list_item_1,nameList);
            flistView.setAdapter(fAdapter);

        }
        else
        {
            Toast.makeText(MessList.this,"No Mess found",Toast.LENGTH_LONG).show();
        }

        dbf.close();
    }
}
