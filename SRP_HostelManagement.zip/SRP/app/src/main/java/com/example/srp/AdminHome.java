package com.example.srp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.srp.AdminLogin;
import com.example.srp.R;
import com.example.srp.StudentLogin;

public class AdminHome extends AppCompatActivity {

    CardView hostel;
    CardView hfeedback;
    CardView Mess;
    CardView Mfeedback;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_home);

        hostel=findViewById(R.id.addhostel);
        hfeedback=findViewById(R.id.hostelfeedback);
        Mess=findViewById(R.id.addmess);
        Mfeedback=findViewById(R.id.messfeedback);

        hostel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AdminHome.this, HostelList.class));

            }
        });

        hfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminHome.this, HostelScreen.class));

            }
        });

        Mess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AdminHome.this, MessList.class));

            }
        });

        Mfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminHome.this, MessScreen.class));

            }
        });


    }
}