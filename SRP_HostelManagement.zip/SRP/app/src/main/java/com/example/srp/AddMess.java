package com.example.srp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;


public class AddMess extends AppCompatActivity {

    EditText nameEdit,BoysGirlsEdit, mobileEdit, mailEdit,  userEdit, passEdit;
    Button addButton;

    DBAdapterMess dbf;

    String nameString,BoysGirlsString, mobileString, mailString,userString, passString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_mess);

        dbf = new DBAdapterMess(AddMess.this);

        nameEdit = (EditText) findViewById(R.id.name);
        BoysGirlsEdit=(EditText) findViewById(R.id.boysgirls);
        mobileEdit = (EditText) findViewById(R.id.mobile);
        mailEdit = (EditText) findViewById(R.id.mail);
        userEdit = (EditText) findViewById(R.id.username);
        passEdit = (EditText) findViewById(R.id.password);
        addButton = (Button) findViewById(R.id.add);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                nameString = nameEdit.getText().toString();
                BoysGirlsString = BoysGirlsEdit.getText().toString();
                mobileString = mobileEdit.getText().toString();
                mailString = mailEdit.getText().toString();
                userString = userEdit.getText().toString();
                passString = passEdit.getText().toString();

                if (nameString.length() > 0 && BoysGirlsString.length() > 0 && mobileString.length() > 0 && mailString.length() > 0 && userString.length() > 0 && passString.length() > 0) {

                    dbf.open();
                    long id = dbf.insertmess(nameString, BoysGirlsString, mobileString, mailString, userString, passString);
                    dbf.close();

                    if (id > 0) {
                        Intent in = new Intent(AddMess.this, MessList.class);
                        startActivity(in);
                        finish();
                    }

                } else {
                    Toast.makeText(AddMess.this, "Please verify all the fields", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        nameEdit.setText("");
        BoysGirlsEdit.setText("");
        mobileEdit.setText("");
        mailEdit.setText("");
        userEdit.setText("");
        passEdit.setText("");
    }
}
