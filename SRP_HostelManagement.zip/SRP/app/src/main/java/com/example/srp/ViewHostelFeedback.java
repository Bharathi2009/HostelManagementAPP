package com.example.srp;

import android.database.Cursor;
import android.os.Bundle;

import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewHostelFeedback extends AppCompatActivity {

    String getusername;
    DBAdapterComment dbc;
    Cursor c;

  ArrayList<String> commentArray = new ArrayList<>();
    ArrayList<String> getRatingArray = new ArrayList<>();

    ListView clist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_hostel_feedback);

        dbc = new DBAdapterComment(ViewHostelFeedback.this);

        getusername = getIntent().getStringExtra("username");

        clist = (ListView) findViewById(R.id.commentlist);

    }

    @Override
    protected void onResume() {
        super.onResume();

        getRatingArray.clear();
        commentArray.clear();

        dbc.open();

        try {
            c = dbc.getAllAccounts();

            if (c.getCount() > 0) {
                c.moveToFirst();

                do {
                    String name = c.getString(c.getColumnIndex("name"));
                    String status = c.getString(c.getColumnIndex("status"));
                    String rating = c.getString(c.getColumnIndex("rating"));



                    if (getusername.equals(name)) {

                        String[] ratingArray = rating.toString().split(",");


                        for (int i = 0; i < ratingArray.length; i++) {
                            getRatingArray.add("\n" + ratingArray[i].toString());
                        }

                        commentArray.add("Name: " + getusername + "\n\nRating: " + getRatingArray.toString().replace("[", "").replace("]", ""));
                    }

                } while (c.moveToNext());

                ArrayAdapter<String> cAdapter = new ArrayAdapter<String>(ViewHostelFeedback.this, android.R.layout.simple_list_item_1, commentArray);
                clist.setAdapter(cAdapter);
            }

            dbc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
